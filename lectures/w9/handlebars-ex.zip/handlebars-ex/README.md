This is a Handlebars.js tutorial slightly modified from:

<a href="http://www.korenlc.com/handlebars-js-tutorial-templating-with-handlebars/" target="_blank">Handlebars.js Tutorial: Templating with Handlebars</a>
