var express = require('express');
var path = require('path');
var app = express();

// setup views
app.locals.basedir = __dirname + '/views';
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');


app.get('/', function(req, res) {
    var title = "Home Page"
	res.render('index', {"pageTitle": title});
});

app.listen(3000, function() {
  console.log('App is running.');
});
