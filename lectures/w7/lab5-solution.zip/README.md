# Lab 5: Ajax and REST


I have moved the instructions to the starter directory, and deleted them from here to avoid confusion.