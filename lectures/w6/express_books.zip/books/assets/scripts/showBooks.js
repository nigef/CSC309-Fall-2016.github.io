function buildList() {
    $.get('books', function (data) {
        let parent = $('#blist');
        let bkObj = JSON.parse(data);
        let bkArray = bkObj.longlist;
        for(let i = 0; i < bkArray.length; i++) {
            let tmp = $('<li>').text(bkArray[i].title + ' by ' + 
                                     bkArray[i].author);
                parent.append(tmp);
        }
    });
}


$(document).ready(function() {
    $("#add").submit(function (e) {
        e.preventDefault();
        console.log($('form').serialize())
        $.post('/addbook', $('form').serialize());
        location.reload(true);

    });
/*    $("#remove").submit(function (e) {
        e.preventDefault();
        let num = $('#number').val();
        console.log($('#number').val());
        $.ajax({
            url: '/remove',
            type: 'DELETE',
            data: {'num' : num},
            success: function result(){
                location.reload(true);
            }
        });
*/    
    $("#remove").submit(function (e) {
        e.preventDefault();
        let num = $('#number').val();
        $.ajax({
            // The book id is part of the resource
            url: '/remove/' + num,
            type: 'DELETE',
            success: function result() {
                location.reload(true);
            }
        });

    });
    
	buildList();
    
    
});